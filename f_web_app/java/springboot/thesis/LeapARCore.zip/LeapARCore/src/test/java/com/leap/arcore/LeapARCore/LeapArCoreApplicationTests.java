package com.leap.arcore.LeapARCore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeapArCoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
