package org.applitics.usage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsageApplicationTests {

	@Test
	void contextLoads() {
	}

}
