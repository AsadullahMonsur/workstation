package com.hospital.others;
public class Patient extends Personnel {
	
	public Patient(String name, String id, String gender, int age) {
		super(name, id, gender, age);
	}

}