package HospitalManagementSystem;

public class InvalidPatientException extends Exception  {
	public InvalidPatientException() {
		super ();
		String id;
		
			
		}

	

	}
