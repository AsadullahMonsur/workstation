package LAB8_17101157;
public class Patient extends Personnel {
	
	public Patient(String name, String id, String gender, int age) {
		super(name, id, gender, age);
	}

}