public class Button_Html {
    
    String opening_tag = "<button type=\"button\" ";
    String closing_tag ="</button>";
    String label ="> Button";
    String id_default ="id=\"default\" ";
    
    private String total ="";
    
    public Button_Html(String id, String label){
        this.id_default = "id=\""+id+"\" ";
        this.label = ">"+label;
        total = opening_tag + id_default + this.label + closing_tag;
    }
    
    public void add_property(String property){
        total = opening_tag + id_default + property + label + closing_tag;
    }

    public String getTotal() {
        return total;
    }
}
