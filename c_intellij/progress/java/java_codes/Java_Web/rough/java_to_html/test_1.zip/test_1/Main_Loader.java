import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStream;
import java.io.PrintStream;

public class MainLoader {
    public static void main(String arg[]){
        Button_Html  b = new Button_Html("001","Click");
     
    try{
        BufferedReader css_txt = new BufferedReader(new FileReader("E:\asadullah\web\Java_Web\test_1\css_text.txt"));
        OutputStream css_file  = new FileOutputStream(new File("E:\asadullah\web\Java_Web\test_1\css_text.css"));
        PrintStream print_html = new PrintStream(css_file);
            
            print_html.println(b.getTotal());
            print_html.close();
            
            css_file.close();
            css_txt.close();
            System.out.println("Done");
        }
        catch (Exception e) {
            e.printStackTrace();
      }
    
        Java_to_Html  jvh = new Java_to_Html("In the Name of Allah",
                               "E:\asadullah\web\Java_Web\test_1\css_text.css"",
                               "E:\asadullah\web\Java_Web\test_1\css_text.css"",
                               "E:\asadullah\web\Java_Web\test_1\css_text.css"",
                               "E:\asadullah\web\Java_Web\test_1\css_text.css");
    
    
    }
}