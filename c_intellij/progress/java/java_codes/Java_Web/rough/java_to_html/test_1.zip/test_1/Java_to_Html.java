import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStream;
import java.io.PrintStream;

public class Java_to_Html{
    
    public Java_to_Html(String tab_title,String html_text_path,
                  String html_file_path,String css_text_path,String css_file_path){
        try {
            BufferedReader css_txt  = new BufferedReader(new FileReader(css_text_path));
            OutputStream css_file   = new FileOutputStream(new File(css_file_path));
            PrintStream print_html  = new PrintStream(css_file);
            String txt_by_line[]    = new String[3000];
            String txtFileData      = "";
            
            int line_num = 0 ;
            
            while ((txt_file_data = css_txt.readLine())! = null){
                txt_by_line[line_num] = txt_file_data;
                line_num++;
            }
            
            for(int i=0;i<line_num;i++){
               print_html.println(txt_by_line[i]);
            }
            
            print_html.close();
            css_file.close();
            css_txt.close();
            
            System.out.println("Done");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        
        try {
            BufferedReader htxt = new BufferedReader(new FileReader(html_text_path));
            OutputStream html_file= new FileOutputStream(new File(html_file_path));
            PrintStream print_html = new PrintStream(html_file);
            
            String txt_by_line[] = new String[3000];
            String temp = "";
            String txt_file_data = "";
            
            String html_header = "<html><head>";
            html_header+="<title>"+tab_title+"</title>"+"<link rel=\"stylesheet\" href=\""+css_file_path+"\">";;
            html_header+="</head><body>";
            String html_footer="</body></html>";
            
            int line_num = 0 ;
            
            while ((txt_file_data = htxt.readLine())!=null){
                txt_by_line[line_num] = txt_file_data;
                line_num++;
            }
            
            for(int i=0;i<linenum;i++){
                if(i == 0){
                    temp = html_header + txt_by_line[0];
                    txt_by_line[0] = temp;
                }
                if(linenum==i+1){
                    temp = txt_by_line[i] + html_footer;
                    txt_by_line[i] = temp;
                }
                print_html.println(txt_by_line[i]);
            }
            
            print_html.close();
            html_file.close();
            htxt.close();
            System.out.println("Done");
        }
        
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}

