public class Main_Loader{
    public static void main(String args[]){
    Load_Scheduler ls = new Load_Scheduler();
    ls.processor(args);
    }
}