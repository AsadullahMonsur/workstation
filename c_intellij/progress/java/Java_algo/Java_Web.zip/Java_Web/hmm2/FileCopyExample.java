    import java.io.BufferedReader;
    import java.io.FileReader;
    import java.io.FileWriter;
    import java.io.IOException;
    import java.io.File;
    import javax.tools.*;
    public class FileCopyExample  extends Thread{
     
     public static void main(String[] args) {
     
      try {
          File file = new File("Good.java");
         file.createNewFile();
       FileReader fr = new FileReader("html.html");
       BufferedReader br = new BufferedReader(fr);
       FileWriter fw = new FileWriter("Good.java", true);
       String s = br.readLine();
      s =br.readLine();
       int count = Integer.parseInt(s);
        for(int i=1;i<count;i++) { 
        // read a line
        s = br.readLine();
        fw.write("\n"+s); // write to output file
        fw.flush();
        }
       br.close();
       fw.close();
       try{
       Thread.sleep(10000);
       }
       catch(Exception e){
      e.printStackTrace();
           
       }
//       String filess = "Good.java";
//       JavaCompiler j = ToolProvider.getSystemJavaCompiler();
//       int resultss = j.run(null,null,null,filess);  
//       if(resultss==0){
//           System.out.println("Done");
//       }
//       else{
//          System.out.println("Note Done");
//       }
//      
      } catch (IOException e) {
       // TODO Auto-generated catch block
       e.printStackTrace();
      }
     }
    }