public class ButtonJVHtml {
    String openingTag ="<button type=\"button\" ";
    String closingTag ="</button>";
    String label ="> Button";
    String id_default ="id=\"default\" ";
    private String total ="";
    public ButtonJVHtml(String id, String label){
        this.id_default = "id=\""+id+"\" ";
        this.label = ">"+label;
        total = openingTag+id_default+this.label+closingTag;
    }
    public void add_property(String property){
        total = openingTag+id_default+property+label+closingTag;
    }

    public String getTotal() {
        return total;
    }
}
