import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStream;
import java.io.PrintStream;

public class JVHtml{
    public JVHtml(String tabTitle,String htmlTextPath,
                  String htmlFilePath,String cssTextPath,String cssFilePath){
        try {
            BufferedReader csstxt = new BufferedReader(new FileReader(cssTextPath));
            OutputStream cssFile= new FileOutputStream(new File(cssFilePath));
            PrintStream printhtml = new PrintStream(cssFile);
            String txtByLine[] = new String[3000];
            String txtFileData ="";
            int linenum = 0 ;
            while ((txtFileData = csstxt.readLine())!=null){
                txtByLine[linenum] = txtFileData;
                linenum++;
            }
            for(int i=0;i<linenum;i++){
               printhtml.println(txtByLine[i]);
            }
            printhtml.close();
            cssFile.close();
            csstxt.close();
            System.out.println("Done");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        
        try {
            BufferedReader htxt = new BufferedReader(new FileReader(htmlTextPath));
            OutputStream htmlfile= new FileOutputStream(new File(htmlFilePath));
            PrintStream printhtml = new PrintStream(htmlfile);
            
            String txtByLine[] = new String[3000];
            String temp ="";
            String txtFileData ="";
            String htmlheader="<html><head>";
            htmlheader+="<title>"+tabTitle+"</title>"+"<link rel=\"stylesheet\" href=\""+cssFilePath+"\">";;
            htmlheader+="</head><body>";
            String htmlfooter="</body></html>";
            int linenum = 0 ;
            while ((txtFileData = htxt.readLine())!=null){
                txtByLine[linenum] = txtFileData;
                linenum++;
            }
            for(int i=0;i<linenum;i++){
                if(i == 0){
                    temp = htmlheader + txtByLine[0];
                    txtByLine[0] = temp;
                }
                if(linenum==i+1){
                    temp = txtByLine[i] + htmlfooter;
                    txtByLine[i] = temp;
                }
                printhtml.println(txtByLine[i]);
            }
            printhtml.close();
            htmlfile.close();
            htxt.close();
            System.out.println("Done");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}

