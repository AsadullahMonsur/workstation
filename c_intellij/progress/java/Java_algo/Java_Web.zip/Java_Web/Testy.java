import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStream;
import java.io.PrintStream;
public class Testy {
    public static void main(String arg[]){
    ButtonJVHtml  b = new ButtonJVHtml("001","Click It");
     
    try{
        BufferedReader csstxt = new BufferedReader(new FileReader("E:/3.CSE/Practice/Java_algo/Java_Web/hmm/html.txt"));
    OutputStream cssFile= new FileOutputStream(new File("E:/3.CSE/Practice/Java_algo/Java_Web/hmm/html.txt"));
    PrintStream printhtml = new PrintStream(cssFile);
               printhtml.println(b.getTotal());
            printhtml.close();
            cssFile.close();
            csstxt.close();
            System.out.println("Done");
        }
        catch (Exception e) {
            e.printStackTrace();
      }
    JVHtml  jvh = new JVHtml("In the Name of Allah",
                  "E:/3.CSE/Practice/Java_algo/Java_Web/hmm/html.txt",
                  "E:/3.CSE/Practice/Java_algo/Java_Web/hmm/html.html",
                  "E:/3.CSE/Practice/Java_algo/Java_Web/hmm/css.txt",
                  "E:/3.CSE/Practice/Java_algo/Java_Web/hmm/css.css");
    
    
    }
}